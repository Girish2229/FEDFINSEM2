import axios from "axios";
const URL = "http://localhost:5000/tasks";
export const getTasks = () => axios.get(URL);
export const addTask = (task) => axios.post(URL, task);
export const delTask = (id) => axios.delete(`${URL}/${id}`);
export const updTask = (id, t) => axios.put(`${URL}/${id}`, t);
