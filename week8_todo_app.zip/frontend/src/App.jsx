import { useEffect, useState } from "react";
import { getTasks, addTask, delTask, updTask } from "./api";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getTasks().then(r => { setTasks(r.data); setLoading(false); });
  }, []);

  const onAdd = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    const res = await addTask({ title: title.trim(), completed: false });
    setTasks(prev => [...prev, res.data]);
    setTitle("");
  };

  const onToggle = async (t) => {
    const updated = { ...t, completed: !t.completed };
    await updTask(t.id, updated);
    setTasks(prev => prev.map(x => x.id === t.id ? updated : x));
  };

  const onDelete = async (id) => {
    await delTask(id);
    setTasks(prev => prev.filter(x => x.id !== id));
  };

  if (loading) return <p>Loading…</p>;

  return (
    <div style={{ maxWidth: 520, margin: "30px auto", fontFamily: "Arial" }}>
      <h2>To-Do List</h2>

      <form onSubmit={onAdd} style={{ display: "flex", gap: 8 }}>
        <input
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Add a task…"
          style={{ flex: 1, padding: 8 }}
        />
        <button>Add</button>
      </form>

      {tasks.length === 0 ? (
        <p>No tasks yet! Add your first one.</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0 }}>
          {tasks.map(t => (
            <li key={t.id}
                style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid #eee" }}>
              <span
                onClick={() => onToggle(t)}
                style={{ cursor: "pointer", textDecoration: t.completed ? "line-through" : "none" }}>
                {t.completed ? "✔ " : "☐ "}{t.title}
              </span>
              <button onClick={() => onDelete(t.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
